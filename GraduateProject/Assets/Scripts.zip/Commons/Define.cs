using System;
using System.Collections.Generic;
using System.ComponentModel;
using UnityEngine;

public abstract class Define
{
    #region Enum
    #region Boss
    public enum BossState { Intro, Phase1, Transition, Phase2, Death }
    public enum AnimKey
    {
        // ����
        Death, Fall, Fallen, Falling,
        StunIn, StunOut, StunLoop,
        BackDash,
        Run, RunIn, RunOut,
        WalkIn, WalkOut, Walking,

        // 1 Phase ����
        Idle, Land,
        Atk1, Atk2, Atk3, Recover,
        DashAtk,
        ChargeJump, JumpIn, JumpAtkLand, JumpAtkLoop,

        // 2 Phase ����
        Idle2, Entry2, Taunt, TauntOut,
        HeavyAtk, HeavyAtk2, HeavyAtk3,
        LightAtk, StompAtk,
        FrontHeavyAtk,
        ToradoAtkIn, ToradoAtkOut, ToradoAtkLoop,

        // �ű� Stage1 ���� ���� Ű (�״�� ����)
        Entry,
        ToJump, Jumping, ToFall,
        ToWalk, Walk, WalkToIdle,
        WalkBlocking, WalkBLocking2, WalkBlocked, OutBlocked,
        ToBlock, Blocked
    }
    #endregion

    public enum RoomType { Normal, Start, Boss, SemiBoss, Shop }
    public enum PortalDir { up, down, left, right }

    public enum BodyPart
    {
        Hair, Hat, Face,
        Chest, ShoulderL, ShoulderR,
        HandL, HandR,
        WeaponL, WeaponR,
        LegL, LegR
    }

    public enum EquipmentSlot { Head, Chest, Legs, Weapon, Ring, Amulet }

    // ---- ����/������̾� ----
    public enum StatType { PhysAtk, MagicAtk, BaseDmg, MaxHp, CritChance, CritDamage /* �ʿ�� �߰� */ }
    public enum ModMethod { Flat, Percent }
    public enum ModifierOp { Add, Percent }

    [Serializable]
    public struct StatModifier
    {
        public StatType stat;
        public ModMethod method;
        public int value;
    }

    // ==== �� EnemyKind Ȯ��: Undead �迭 �߰� (Stage1) ====
    [Description("�� ����(����/��ü��)")]
    public enum EnemyKind
    {
        // Stage2 - �װ� �� ��ũ
        OrcWarrior,
        OrcGreatsword,
        OrcArcher,
        OrcShaman,

        // Stage1 - �� �ױױױױױ� �𵥵�
        UndeadFarmer,
        UndeadSwordsman,
        UndeadMage
    }

    [Description("���� ���")]
    public enum AttackMode { Melee, Ranged, RangedBuffer }
    #endregion

    #region Class
    public class Edge : IComparable<Edge>
    {
        public MapNode Start { get; }
        public MapNode End { get; }
        public float Distance { get; }

        public Edge(MapNode start, MapNode end)
        {
            Start = start;
            End = end;
            Distance = Vector2.Distance(start.SpaceArea.position, end.SpaceArea.position);
        }
        public int CompareTo(Edge other) => this.Distance.CompareTo(other.Distance);
    }

    public class UnionFind
    {
        private int[] parent;
        private int[] rank;
        public UnionFind(int size)
        {
            parent = new int[size];
            rank = new int[size];
            for (int i = 0; i < size; i++) { parent[i] = i; rank[i] = 0; }
        }
        // �θ� ���󰡸� �����ϸ鼭 ��ǥ�� ã��
        public int Find(int u) { if (parent[u] != u) parent[u] = Find(parent[u]); return parent[u]; }
        // �� ��ǥ�� �񱳷� Ʈ�� ���̰� ���� ���� ���� ��  �ؿ� ����.
        public bool Union(int u, int v)
        {
            int pu = Find(u), pv = Find(v);
            if (pu == pv) return false;
            if (rank[pu] > rank[pv]) parent[pv] = pu;
            else if (rank[pu] < rank[pv]) parent[pu] = pv;
            else { parent[pv] = pu; rank[pu]++; }
            return true;
        }
    }

    public class PortalInfo
    {
        public PortalDir dir;
        public MapNode connected;
        public PortalInfo(PortalDir dir, MapNode connected) { this.dir = dir; this.connected = connected; }
    }

    public class MapNode
    {
        public RectInt SpaceArea;
        public int Id;
        public List<PortalInfo> Portals;
        public MapNode() { Portals = new List<PortalInfo>(); }
    }

    public class AttackContext
    {
        public GameObject Attacker { get; set; }
        public GameObject Target { get; set; }
        public Vector2 Direction { get; set; }
        public int SkillLevel { get; set; }
        public float CritChance { get; set; }
        public AttackContext(GameObject Attacker, GameObject Target, Vector2 Direction)
        { this.Attacker = Attacker; this.Target = Target; this.Direction = Direction; }
    }
    #endregion
}
