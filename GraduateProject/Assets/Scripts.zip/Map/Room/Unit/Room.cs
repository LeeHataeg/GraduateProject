// Room.cs
using System;
using System.Collections.Generic;
using System.Drawing;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Tilemaps;
using static Define;
using Color = UnityEngine.Color;

public class Room : MonoBehaviour
{
    public MapNode Node;
    public RectInt RoomSpace;

    public RoomType Type { get; private set; }
    public RoomState RoomState { get; private set; }
    public PortalConnection PortalConnection { get; private set; }
    public SpawnerController spawnManager { get; private set; }

    private readonly List<Portal> _portals = new();

    private void SetDark()
    {
        // TMI. GetComponentsInChildren�� List�� �ƴ� �迭�� �����Ͽ� �Ʒ��� Ʋ�� ����
        //List<SpriteRenderer> sprites = GetComponentsInChildren<SpriteRenderer>();

        var tilemaps = GetComponentsInChildren<Tilemap>(true);
        var sprites = GetComponentsInChildren<SpriteRenderer>();

        foreach (var tilemap in tilemaps)
        {
            tilemap.color = new Color(0f, 0f, 0f, 1f);
        }

        foreach (var sprite in sprites)
        {
            sprite.color = new Color(0f, 0f, 0f, 1f);
        }
    }

    private void SetLight()
    {

        var tilemaps = GetComponentsInChildren<Tilemap>(true);
        var sprites = GetComponentsInChildren<SpriteRenderer>();

        foreach (var tilemap in tilemaps)
        {
            tilemap.color = new Color(1f, 1f, 1f, 1f);
        }

        foreach (var sprite in sprites)
        {
            sprite.color = new Color(1f, 1f, 1f, 1f);
        }
    }

    public void Initialize(RoomInitData init)
    {
        Node = init.Node;
        RoomSpace = init.RoomSpace;
        Type = init.RoomType;

        RoomState = gameObject.AddComponent<RoomState>();
        PortalConnection = gameObject.AddComponent<PortalConnection>();

        spawnManager = gameObject.GetComponent<SpawnerController>();
        if (spawnManager != null)
        {
            // �� ���� óġ ��: Ŭ���� + ��Ż ����
            // (�̺�Ʈ �̸��� OnAllEnemiesDefeated �Դϴ�!)
            spawnManager.OnAllEnemiesDefeated += HandleAllEnemiesDefeated;
        }

        PortalConnection.Initialize(init.Node.Portals);

        if(init.RoomType != RoomType.Start)
            SetDark();
    }

    private void OnDestroy()
    {
        if (spawnManager != null)
            spawnManager.OnAllEnemiesDefeated -= HandleAllEnemiesDefeated;
    }

    public void CachePortals()
    {
        _portals.Clear();
        GetComponentsInChildren<Portal>(true, _portals);
    }

    public void SetPortalsActive(bool active)
    {
        if (Type == RoomType.Start || Type == RoomType.Boss) return;

        foreach (var p in _portals)
        {
            if (p && p.TryGetComponent<Collider2D>(out var col))
                col.enabled = active;

            // ����: �ð� �ǵ��(������ �����ص� ����)
            var sr = p.GetComponentInChildren<SpriteRenderer>();
            if (sr) sr.color = active ? Color.white : new Color(1, 1, 1, 0.35f);
        }
    }

    private void HandleAllEnemiesDefeated()
    {
        RoomState.RoomCleared();
        SetPortalsActive(true); // ��� ���� óġ �� ��Ż ����
    }

    public Vector2 GetSpawnPosition()
    {
        Vector2 lowerLeft = (Vector2)transform.position;
        Vector2 middle = lowerLeft + new Vector2(RoomSpace.width * 0.5f, RoomSpace.height * 0.5f);
        return middle;
    }

    public void OnPlayerEnter()
    {
        // StartRoom/BossRoom�� ��Ż�� ���� �ʰ�, ���͵� �������� ����
        if (Type == RoomType.Normal)
        {
            SetLight();

            if (!RoomState.IsCleared)
            {
                SetPortalsActive(false);     // ���� �� ��Ż OFF
                spawnManager?.SpawnEnemies(); // ó���� ������(Spawner�� ���������� 1ȸ ����)
            }
            else
            {
                SetPortalsActive(true);      // ��湮(Ŭ���� ��) �� ��Ż ����
            }
        }
    }
}
