using UnityEngine;
using static Define;
[RequireComponent(typeof(Collider2D))]
public class Portal : MonoBehaviour
{
    public PortalDir direction { get; private set; }
    private Room parentRoom;
    private Transform tr;

    private void Awake()
    {
        tr = GetComponent<Transform>();
    }

    /// <summary>
    /// �� ���� �� RoomGenerator���� �� ���� ȣ��
    /// </summary>
    public void Initialize(Room room, PortalDir dir)
    {
        parentRoom = room;
        direction = dir;

        if (dir == PortalDir.up || dir == PortalDir.down)
        {
            tr.eulerAngles = new Vector3 (0, 0, 90f);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            var pm = other.GetComponent<PlayerMovement>();
            pm?.SetCurrentPortal(this);
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            var pm = other.GetComponent<PlayerMovement>();
            pm?.ClearCurrentPortal(this);
        }
    }

    /// <summary>
    /// ���� ��Ż�� ���� ����� �� ��ȯ
    /// </summary>
    public Room GetDestinationRoom()
    {
        return parentRoom.PortalConnection.ConnectedRooms[direction];
    }
}

