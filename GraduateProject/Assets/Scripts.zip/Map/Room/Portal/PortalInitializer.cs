using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;
using Object = UnityEngine.Object;
using static Define;

public class PortalInitializer
{
    [Header("Addressables Key for Portal Prefab")]
    [SerializeField] private string portalAddress = "Portal";
    private GameObject portalPrefab;

    // �ɼ�: �̸��� "Wall"�� Ÿ�ϸ��� �켱 ������ ����(�и� Ÿ�ϸ� ���� ����)
    public string wallTilemapName = "Wall";

    // �� ���� ã�� �� "�� ����"���� �� �о�ְ� ������ 0 �̻����� ����(Ÿ�� ����)
    public int insetFromWall = 0;

    public PortalInitializer(string address = "Portal") { portalAddress = address; }

    public void SetPortalPrefabAsync()
    {
        // ���� ������Ʈ ���� ���� Resources ��� (��� Ȯ�� ���)
        portalPrefab = Resources.Load<GameObject>("Prefabs/Maps/Portal/Portal");
        if (portalPrefab == null)
            throw new InvalidOperationException("Portal prefab load failed: Resources/Prefabs/Maps/Portal/Portal");
    }

    public void Init(List<Room> rooms)
    {
        if (rooms == null || rooms.Count == 0) return;

        // �ڡڡ� �ı�/�� �� ����
        var aliveRooms = new List<Room>(rooms.Count);
        foreach (var r in rooms)
        {
            if (r != null) aliveRooms.Add(r);
        }
        if (aliveRooms.Count == 0) return;

        // ������ ����
        var roomMap = new Dictionary<int, Room>(aliveRooms.Count);
        foreach (var room in aliveRooms)
        {
            if (room?.Node == null) continue;
            // Node.Id�� BSP/MST ���� ���� ����
            if (!roomMap.ContainsKey(room.Node.Id))
                roomMap.Add(room.Node.Id, room);
        }

        foreach (var room in aliveRooms)
        {
            if (room == null) continue;
            if (room.PortalConnection == null || room.PortalConnection.PortalInfos == null) continue;

            foreach (var kv in room.PortalConnection.PortalInfos)
            {
                var dir = kv.Key;
                var destNode = kv.Value;
                if (portalPrefab == null) { Debug.LogError("[PortalInitializer] Portal prefab is null."); continue; }

                // ������ parent(�� Ʈ�������� �ı��Ǿ ���⼱ ��� ����)
                var parent = room.transform;
                if (parent == null) continue; // ���� �� ���� �ı��� ���

                var pObj = Object.Instantiate(portalPrefab, parent);
                var portal = pObj.GetComponent<Portal>();
                if (portal != null)
                    portal.Initialize(room, dir);

                // ������ ����
                if (destNode != null && roomMap.TryGetValue(destNode.Id, out var destRoom) && destRoom != null)
                    room.PortalConnection.ConnectRoom(dir, destRoom);

                // === ��ġ ��� ===
                // 1) �� ���� Ÿ�ϸʵ� ȹ��
                var tilemaps = room.GetComponentsInChildren<Tilemap>(true);
                if (tilemaps == null || tilemaps.Length == 0)
                {
                    Debug.LogError("[PortalInitializer] No Tilemap found in room.");
                    continue;
                }

                // 2) '��' Ÿ�ϸ� ������ (�̸��� Wall �켱, ������ ù Ÿ�ϸ�)
                Tilemap wallMap = null;
                foreach (var tm in tilemaps)
                {
                    if (tm && tm.gameObject.name.Equals(wallTilemapName, StringComparison.OrdinalIgnoreCase))
                    {
                        wallMap = tm;
                        break;
                    }
                }
                if (!wallMap) wallMap = tilemaps[0];
                if (!wallMap) { Debug.LogError("[PortalInitializer] Tilemap missing."); continue; }

                wallMap.CompressBounds();
                var b = wallMap.cellBounds;
                if (b.size.x <= 0 || b.size.y <= 0)
                {
                    Debug.LogWarning("[PortalInitializer] Tilemap bounds empty.");
                    continue;
                }

                // �߾� �ε���(���� �� �ε���) ���
                int cx = Mathf.Clamp((b.xMin + b.xMax - 1) / 2, b.xMin, b.xMax - 1);
                int cy = Mathf.Clamp((b.yMin + b.yMax - 1) / 2, b.yMin, b.yMax - 1);

                // 3) �� �������κ��� ��ĵ�Ͽ� "�� ��(HasTile == false)"�� ã�´�.
                Vector3Int targetCell = new Vector3Int(cx, cy, 0);

                switch (dir)
                {
                    case PortalDir.right:
                        {
                            for (int x = b.xMax - 1; x >= b.xMin; x--)
                            {
                                var c = new Vector3Int(x, cy, 0);
                                if (!wallMap.HasTile(c))
                                {
                                    c.x = Mathf.Clamp(c.x - insetFromWall, b.xMin, b.xMax - 1);
                                    targetCell = c; break;
                                }
                            }
                            break;
                        }
                    case PortalDir.left:
                        {
                            for (int x = b.xMin; x < b.xMax; x++)
                            {
                                var c = new Vector3Int(x, cy, 0);
                                if (!wallMap.HasTile(c))
                                {
                                    c.x = Mathf.Clamp(c.x + insetFromWall, b.xMin, b.xMax - 1);
                                    targetCell = c; break;
                                }
                            }
                            break;
                        }
                    case PortalDir.up:
                        {
                            for (int y = b.yMax - 1; y >= b.yMin; y--)
                            {
                                var c = new Vector3Int(cx, y, 0);
                                if (!wallMap.HasTile(c))
                                {
                                    c.y = Mathf.Clamp(c.y - insetFromWall, b.yMin, b.yMax - 1);
                                    targetCell = c; break;
                                }
                            }
                            break;
                        }
                    case PortalDir.down:
                    default:
                        {
                            for (int y = b.yMin; y < b.yMax; y++)
                            {
                                var c = new Vector3Int(cx, y, 0);
                                if (!wallMap.HasTile(c))
                                {
                                    c.y = Mathf.Clamp(c.y + insetFromWall, b.yMin, b.yMax - 1);
                                    targetCell = c; break;
                                }
                            }
                            break;
                        }
                }

                // 4) �� �߽� ���� ��ǥ�� ��ġ
                var pos = wallMap.GetCellCenterWorld(targetCell);
                pObj.transform.position = pos;
            }

            // �� ���� ��Ż ĳ�� ���� (room�� ������� ����)
            if (room != null) room.CachePortals();
        }
    }
}
