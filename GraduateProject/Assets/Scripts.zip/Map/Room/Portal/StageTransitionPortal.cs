using UnityEngine;

[RequireComponent(typeof(Collider2D))]
public class StageTransitionPortal : MonoBehaviour
{
    private void Reset()
    {
        if (TryGetComponent<Collider2D>(out var col))
            col.isTrigger = true;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!other || !other.CompareTag("Player")) return;

        // Stage1 �� Stage2 ��ȯ
        GameManager.Instance?.AdvanceToNextStage();

        // Destroy(gameObject); // ���ϸ� 1ȸ��
    }
}
