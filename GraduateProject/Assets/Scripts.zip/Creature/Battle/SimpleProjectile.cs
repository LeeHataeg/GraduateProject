using System.Collections;
using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(Collider2D))]
[DisallowMultipleComponent]
public class SimpleProjectile : MonoBehaviour
{
    private Rigidbody2D rb;
    private Collider2D col;

    // ����
    private GameObject owner;
    private float damage;
    private LayerMask hitMask;
    private bool fired;

    [Header("Defaults (Init ��ȣ�� �� ���)")]
    [SerializeField] private bool autoFireOnEnable = false; // �⺻ ���д�
    [SerializeField] private float defaultSpeed = 12f;
    [SerializeField] private float defaultLifeTime = 5f;
    [SerializeField] private float angleOffsetDeg = 0f; // ��������Ʈ ������

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        col = GetComponent<Collider2D>();
        rb.gravityScale = 0f;
        col.isTrigger = true;

        // ����: Dynamic + ���� Linear Drag
        rb.bodyType = RigidbodyType2D.Dynamic;
        rb.linearDamping = 0f; // �ʿ�� 0~0.1
    }

    private void OnEnable()
    {
        fired = false;
        CancelInvoke();

        if (autoFireOnEnable)
            StartCoroutine(Co_AutoFireNextFrame()); // Init�� ���� �� ��ȸ�� �ش�
    }

    private IEnumerator Co_AutoFireNextFrame()
    {
        yield return null; // �� ������ ���
        if (fired) yield break;

        var player = GameObject.FindGameObjectWithTag("Player")?.transform;
        if (player != null)
            Fire((player.position - transform.position).normalized,
                 defaultSpeed, defaultLifeTime, damage, owner, ~0);
    }

    /// <summary>�ܺο��� �ݵ�� ȣ��(��õ): ��� ȸ��/�ӵ�/���� ����</summary>
    public void Init(Vector2 direction, float dmg, GameObject owner, LayerMask hitMask, float speed, float lifeTime)
    {
        this.owner = owner;
        this.damage = dmg;
        this.hitMask = hitMask;
        Fire(direction.normalized, speed, lifeTime, dmg, owner, hitMask);
    }

    private void Fire(Vector2 dir, float speed, float lifeTime, float dmg, GameObject owner, LayerMask mask)
    {
        Debug.Log(gameObject.name + " speed : " + speed);
        // ȸ��
        float angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg + angleOffsetDeg;
        rb.SetRotation(angle);

        // �ӵ� ��� ���� (Unity 6 ���� �Ӽ�)
#if UNITY_6000_0_OR_NEWER
        rb.linearVelocity = dir * speed;
#else
        rb.velocity = dir * speed;
#endif

        // ����
        if (lifeTime > 0f) Invoke(nameof(Despawn), lifeTime);

        // ����
        this.damage = dmg;
        this.owner = owner;
        this.hitMask = mask;
        fired = true;
    }

    private void Despawn()
    {
        gameObject.SetActive(false);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!other || !other.gameObject) return;
        if (owner && other.transform.IsChildOf(owner.transform)) return; // �ڱ� �� ����
        if ((hitMask.value & (1 << other.gameObject.layer)) == 0) return;

        var reactor = other.GetComponent<IHitReactor>();
        if (reactor != null)
        {
            reactor.OnAttacked(damage);
            Despawn();
        }
    }

    // ����� ��: ���� �ӵ��� ������ Ȯ���ϰ� ������ �����
    // private Vector2 last;
    // private void FixedUpdate()
    // {
    // #if UNITY_6000_0_OR_NEWER
    //     var v = rb.linearVelocity;
    // #else
    //     var v = rb.velocity;
    // #endif
    //     if (v != last) { Debug.Log($"[Projectile] vel={v} (frame {Time.frameCount})"); last = v; }
    // }
}
