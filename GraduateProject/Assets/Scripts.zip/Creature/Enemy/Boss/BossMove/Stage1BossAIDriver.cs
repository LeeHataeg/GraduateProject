using System.Collections;
using UnityEngine;

[DisallowMultipleComponent]
public class Stage1BossAIDriver : MonoBehaviour
{
    [Header("Refs")]
    public BossAIProfileSO profile;
    public Transform player;                // ���� �ڵ� Ž��(Tag=Player)
    public Animator anim;                   // ���� �ڵ� Ž��(�ڽ�)
    public Rigidbody2D rb;                  // ����(���� �� �ӵ� �����)
    public LayerMask groundMaskOverride;    // ���� profile.groundMask ���

    [Header("Animator Triggers (Stage1 ����)")]
    public string TR_ToJump = "ToJump";
    public string TR_LightAtk = "LightAtk";
    public string TR_FrontHeavy = "FrontHeavyAtk";

    [Header("State")]
    public bool debugLog;
    private float lastJumpT, lastLightT, lastHeavyT;
    private bool grounded;

    private float senseTimer;

    private void Reset()
    {
        anim = GetComponentInChildren<Animator>();
        rb = GetComponent<Rigidbody2D>();
    }

    private IEnumerator Start()
    {
        if (!profile)
        {
            Debug.LogError("[Stage1BossAIDriver] Profile is null.", this);
            enabled = false; yield break;
        }
        if (!player)
        {
            var p = GameObject.FindGameObjectWithTag("Player");
            if (p) player = p.transform;
        }
        if (!anim) anim = GetComponentInChildren<Animator>();
        if (!rb) rb = GetComponent<Rigidbody2D>();

        // ���� ����
        while (true)
        {
            TickSenseAndDecide();
            float dt = Mathf.Max(0.02f, profile.senseInterval);
            yield return new WaitForSeconds(dt);
        }
    }

    private void TickSenseAndDecide()
    {
        if (!player || !anim) return;

        // --- ���� ---
        Vector2 pos = transform.position;
        Vector2 ppos = player.position;
        float dx = ppos.x - pos.x;
        float dy = ppos.y - pos.y;
        float ax = Mathf.Abs(dx);
        float ay = Mathf.Abs(dy);
        float now = Time.time;

        grounded = ProbeGrounded(pos);

        // ���̽� ���� ����(����)
        if (Mathf.Abs(dx) > profile.faceFlipThreshold)
        {
            Vector3 sc = transform.localScale;
            sc.x = Mathf.Sign(dx) * Mathf.Abs(sc.x);
            transform.localScale = sc;
        }

        // --- �켱: ���� ���� ---
        bool wantJump =
            grounded &&
            ay >= profile.jumpYThreshold &&
            ax >= profile.jumpMinX && ax <= profile.jumpMaxX &&
            (now - lastJumpT) >= profile.jumpCooldown;

        // --- ���� �ĺ� ---
        bool inLight =
            ax >= profile.lightMinX && ax <= profile.lightMaxX &&
            ay <= profile.lightMaxAbsY &&
            (now - lastLightT) >= profile.lightCooldown;

        bool inHeavy =
            ax >= profile.heavyMinX && ax <= profile.heavyMaxX &&
            ay <= profile.heavyMaxAbsY &&
            (now - lastHeavyT) >= profile.heavyCooldown &&
            HasFrontLineOfSight(pos, dx);

        // �ǻ����: Jump > ����(����ġ) > ���
        if (wantJump)
        {
            TriggerOnce(TR_ToJump);
            lastJumpT = now;
            if (debugLog) Debug.Log("[Stage1BossAIDriver] JUMP", this);
            return;
        }

        if (inLight || inHeavy)
        {
            // �� �� �Ǹ� preferHeavy ������� ����
            if (inLight && inHeavy)
            {
                if (Random.value < profile.preferHeavy) FireHeavy();
                else FireLight();
            }
            else if (inHeavy) FireHeavy();
            else FireLight();

            return;
        }

        // �� ��: �ƹ� �͵� �� ��(Idle ����)
    }

    private void FireLight()
    {
        TriggerOnce(TR_LightAtk);
        lastLightT = Time.time;
        if (debugLog) Debug.Log("[Stage1BossAIDriver] LightAtk", this);
    }

    private void FireHeavy()
    {
        TriggerOnce(TR_FrontHeavy);
        lastHeavyT = Time.time;
        if (debugLog) Debug.Log("[Stage1BossAIDriver] FrontHeavyAtk", this);
    }

    private void TriggerOnce(string trig)
    {
        if (string.IsNullOrEmpty(trig) || !anim) return;
        // ���� ������ �ߺ� ���� �� �缳��
        anim.ResetTrigger(trig);
        anim.SetTrigger(trig);
    }

    private bool ProbeGrounded(Vector2 from)
    {
        var mask = (groundMaskOverride.value != 0) ? groundMaskOverride : profile.groundMask;
        // �� �Ʒ� ���� ����
        RaycastHit2D hit = Physics2D.Raycast(from + Vector2.down * 0.05f, Vector2.down, 0.2f, mask);
        return hit.collider != null;
    }

    private bool HasFrontLineOfSight(Vector2 from, float dx)
    {
        // �������θ� ���ü� üũ(�� ���̿� �÷��̾ ������ Heavy�� ����)
        var dir = new Vector2(Mathf.Sign(dx), 0f);
        float len = profile.losRayLength;
        var mask = (groundMaskOverride.value != 0) ? groundMaskOverride : profile.groundMask;
        var hit = Physics2D.Raycast(from + Vector2.up * 0.5f, dir, len, mask);
        // ���� ���� ������ ������ true
        return hit.collider == null;
    }
}
