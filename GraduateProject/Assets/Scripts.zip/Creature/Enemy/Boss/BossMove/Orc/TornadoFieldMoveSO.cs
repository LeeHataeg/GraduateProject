using static Define;
using UnityEngine;
using System.Collections;

[CreateAssetMenu(menuName = "Boss/Moves/Tornado Field")]
public class TornadoFieldMoveSO : BossMoveSO
{
    public AnimKey enterKey = AnimKey.ToradoAtkIn;
    public AnimKey loopBoolKey = AnimKey.ToradoAtkLoop; // Bool ����
    public AnimKey exitKey = AnimKey.ToradoAtkOut;

    public GameObject fieldPrefab;
    public float lifeTime = 6f;

    protected override IEnumerator Execute(BossContext ctx)
    {
        // In
        ctx.Anims.Play(ctx.Anim, enterKey);
        yield return new WaitForSeconds(0.15f);

        // Loop on + �ʵ� ����
        ctx.Anims.Play(ctx.Anim, loopBoolKey, true);
        if (fieldPrefab)
        {
            var go = GameObject.Instantiate(fieldPrefab, ctx.AttackOrigin.position, Quaternion.identity);
            GameObject.Destroy(go, lifeTime);
        }

        // ���� ���� �ð��� recover/cooldown���� �����ϰų�,
        // AE_Hit/AE_PhaseGate �̺�Ʈ�� ��� �ȴ�. ���⼭�� recover���� ���� ����
        if (recover > 0) yield return new WaitForSeconds(recover);

        // Loop off + Out
        ctx.Anims.Play(ctx.Anim, loopBoolKey, false);
        ctx.Anims.Play(ctx.Anim, exitKey);
    }
}
