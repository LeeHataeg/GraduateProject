using UnityEngine;
using System.Collections;
using static Define;

[CreateAssetMenu(menuName = "Boss/Moves/Jump Chase")]
public class JumpChaseMoveSO : BossMoveSO
{
    [Header("Anim Keys")]
    public AnimKey toJump = AnimKey.ToJump;
    public AnimKey jumping = AnimKey.Jumping;
    public AnimKey toFall = AnimKey.ToFall;
    public AnimKey falling = AnimKey.Falling;
    public AnimKey land = AnimKey.Land;

    [Header("Jump Physics")]
    public float jumpUpVelocity = 9f;        // ���� �ʼ�
    public float airHSpeed = 3.2f;           // ���� ���� �̵� �ӵ�(���󺸴� ����)
    public float maxJumpWait = 1.0f;         // ��¡��ϰ� ��ȯ���� �ִ� ���

    protected override IEnumerator Execute(BossContext ctx)
    {
        var rb = ctx.RB;
        if (!rb) yield break;

        // ToJump (1ȸ)
        ctx.Anims.Play(ctx.Anim, toJump);
        yield return new WaitForSeconds(0.05f);

        // Jumping: �ʼ� �ο� + ���߿��� x���� ���� �̵�
#if UNITY_6000_0_OR_NEWER
        var v = rb.linearVelocity; v.y = jumpUpVelocity; rb.linearVelocity = v;
#else
        var v = rb.velocity; v.y = jumpUpVelocity; rb.velocity = v;
#endif
        ctx.Anims.Play(ctx.Anim, jumping);

        float t = 0f;
        while (t < maxJumpWait)
        {
            t += Time.fixedDeltaTime;

            // �÷��̾� �������� ���� �̵�
            if (ctx.Player)
            {
                float dx = ctx.Player.position.x - ctx.Self.position.x;
#if UNITY_6000_0_OR_NEWER
                var vv = rb.linearVelocity;
#else
                var vv = rb.velocity;
#endif
                vv.x = Mathf.MoveTowards(vv.x, Mathf.Sign(dx) * airHSpeed, 8f * Time.fixedDeltaTime);
#if UNITY_6000_0_OR_NEWER
                rb.linearVelocity = vv;
#else
                rb.velocity = vv;
#endif
            }

            // �ϰ����� ��ȯ(�߷¿� �ð� y<=0 �Ǵ� ����)
#if UNITY_6000_0_OR_NEWER
            if (rb.linearVelocity.y <= 0f) break;
#else
            if (rb.velocity.y <= 0f) break;
#endif
            yield return new WaitForFixedUpdate();
        }

        // ToFall (1ȸ)
        ctx.Anims.Play(ctx.Anim, toFall);
        yield return new WaitForSeconds(0.05f);

        // Falling: �� ���� ������
        bool grounded = false;
        var boss = ctx.Self.GetComponent<BossController>();
        System.Action onGround = () => grounded = true;
        if (boss != null) boss.GroundTouched += onGround;

        ctx.Anims.Play(ctx.Anim, falling);
        float watchdog = 2.0f;
        while (!grounded && watchdog > 0f)
        {
            watchdog -= Time.deltaTime;
            yield return null;
        }
        if (boss != null) boss.GroundTouched -= onGround;

        // Land(1ȸ)
        ctx.Anims.Play(ctx.Anim, land);
        yield return new WaitForSeconds(0.1f);
    }
}
