using UnityEngine;

/// �ִϸ��̼� �̺�Ʈ�� ���� AttackHitbox�� BossController�� ����
public class AnimationEventRelay : MonoBehaviour
{
    private BossController boss;

    [Header("Single Hitbox (optional but recommended)")]
    public AttackHitbox hitbox; // �ڽ� Hitbox �Ҵ�

    void Awake()
    {
        boss = GetComponentInParent<BossController>();
        if (!hitbox) hitbox = GetComponentInChildren<AttackHitbox>();
    }

    // ---- ��Ʈ ������ ----
    public void AE_HitBegin() { hitbox?.BeginWindow(); }
    public void AE_HitEnd() { hitbox?.EndWindow(); }

    // ---- ���̷ε� �ǽð� ����(����) ----
    public void AE_SetDamage(float dmg) { hitbox?.SetPayload(dmg); }
    public void AE_SetKnockbackX(float x) { if (hitbox) hitbox.SetKnockback(x, hitbox ? hitbox.GetComponent<AttackHitbox>().knockback.y : 0f); }
    public void AE_SetKnockback(float x, float y) { hitbox?.SetKnockback(x, y); }

    // ---- ��Ÿ ��ȣ ----
    public void AE_Hit() { boss?.OnAE_Hit(); }
    public void AE_Spawn(string id) { boss?.OnAE_Spawn(id); }
    public void AE_InvulnOn() { boss?.OnAE_Invuln(true); }
    public void AE_InvulnOff() { boss?.OnAE_Invuln(false); }
    public void AE_PhaseGate() { boss?.OnAE_PhaseGate(); }
}
