using UnityEngine;
using static Define;

[CreateAssetMenu(menuName = "Boss/Definition")]
public class BossDefinitionSO : ScriptableObject
{
    public AnimMapSO animMap;

    [Header("Phases (Phase2�� ����� �� ����)")]
    public BossPhaseSO phase1;
    public BossPhaseSO phase2;

    [Header("Single-Phase Option")]
    public bool singlePhase = false;

    public enum IntroMode { FallFromSky, PlayEntryOnce }

    [Header("Intro/Idle/Walking Keys")]
    public IntroMode introMode = IntroMode.FallFromSky;
    public AnimKey entryKey = AnimKey.Entry;   // introMode=PlayEntryOnce �� �� ���
    public AnimKey idleKey = AnimKey.Idle;     // Idle ������ ����� Ű(���¸�)
    public AnimKey walkingBoolKey = AnimKey.Walking;

    [Header("Death/Fade")]
    public AnimKey deathKey = AnimKey.Death;
    public float fadeDelay = 1.2f;
}
