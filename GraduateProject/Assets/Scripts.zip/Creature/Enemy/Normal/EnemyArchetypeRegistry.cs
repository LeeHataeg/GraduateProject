using System.Collections.Generic;
using UnityEngine;
using static Define;

public static class EnemyArchetypeRegistry
{
    // stage -> (roomType -> catalog)
    private static readonly Dictionary<int, Dictionary<RoomType, EnemyArchetypeCatalog>> byStage
        = new();

    private static bool loaded = false;

    // ���� ��ε� ����
    private static readonly string[] DefaultPaths =
    {
        "Enemies/Archetypes",
        "SO/Stats/Enemies/Archetype",
        ""
    };

    public static void LoadAll(params string[] searchPaths)
    {
        if (loaded) return;
        var paths = (searchPaths != null && searchPaths.Length > 0) ? searchPaths : DefaultPaths;

        int found = 0;
        foreach (var p in paths)
        {
            var all = Resources.LoadAll<EnemyArchetypeCatalog>(p);
            foreach (var c in all)
            {
                if (!c) continue;
                if (!byStage.TryGetValue(c.stage, out var dict))
                {
                    dict = new Dictionary<RoomType, EnemyArchetypeCatalog>();
                    byStage[c.stage] = dict;
                }
                // ���� Ű �浹 �� ���������� �ε�� �ɷ� �����(������ ��Ģ)
                dict[c.roomType] = c;
                found++;
            }
            if (found > 0) break; // ù ��ο��� ã������ ����(�ε� ��� ����)
        }

#if UNITY_EDITOR
        if (found == 0)
            Debug.LogWarning("[EnemyArchetypeRegistry] No catalogs found. " +
                             "Create EnemyArchetypeCatalog under Resources.");
#endif
        loaded = true;
    }

    // �� �ű� API: stage + roomType���� ��ȸ
    public static EnemyArchetypeCatalog GetCatalog(int stage, RoomType roomType, params string[] preferredPaths)
    {
        if (!loaded) LoadAll(preferredPaths);
        if (byStage.TryGetValue(stage, out var dict))
        {
            dict.TryGetValue(roomType, out var c);
            return c;
        }
        return null;
    }

    // ������ ȣȯ(�������� ������ �� 1�� ����)
    public static EnemyArchetypeCatalog GetCatalog(RoomType roomType, params string[] preferredPaths)
        => GetCatalog(1, roomType, preferredPaths);
}
