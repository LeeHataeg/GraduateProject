using System;
using UnityEngine;

[DefaultExecutionOrder(-50)] // StatController(-100) ������ ����ǵ��� �ణ ������
public class HealthController : MonoBehaviour, IHealth
{
    public float currentHp;
    private CombatStatSheet stats;
    private ICombatStatHolder holder;

    public float CurrentHp => currentHp;
    public CombatStatSheet Stats => stats;
    public float MaxHp => stats != null ? stats.MaxHp : 1f;

    public event Action OnDead;
    public event Action<float, float> OnHealthChanged;

    private void Awake()
    {
        FindStatHolder(needLog: true);
    }

    private void Start()
    {
        if (stats == null) 
            FindStatHolder(needLog: false);

        if (stats != null)
        {
            currentHp = stats.MaxHp;
            OnHealthChanged?.Invoke(currentHp, stats.MaxHp);
        }
        else
        {
            Debug.LogError($"[HC] : '{name}' stats�� null");
            currentHp = 1f;
        }
    }

    private void FindStatHolder(bool needLog)
    {
        holder = GetComponent<ICombatStatHolder>();

        if (holder == null)
            holder = GetComponentInParent<ICombatStatHolder>();

        if (holder == null)
            holder = GetComponentInParent<ICombatStatHolder>();         //�θ�κ��� Ž��
        if (holder == null)
            holder = GetComponentInChildren<ICombatStatHolder>(true);   // ������ �ڽĿ��� Ž��

        if (holder != null)
        {
            stats = holder.Stats;
            if (stats == null)
            {
                if (!needLog)
                    Debug.LogWarning($"[HC] '{name}' ICombatStatHolder�� ����, Stats�� ���� null.");
            }
        }
        else if (!needLog)
        {
            Debug.LogError($"[HC] '{name}' ICombatStatHolder ����.");
        }
    }

    public void Heal(float amount)
    {
        if (stats == null) return;
        currentHp = Mathf.Min(currentHp + amount, stats.MaxHp);
        OnHealthChanged?.Invoke(currentHp, stats.MaxHp);
    }

    public void TakeDamage(float amount)
    {
        if (stats == null) return;

        float before = currentHp;
        currentHp -= amount;

        if (currentHp <= 0f)        // ���
        {
            currentHp = 0f;
            OnDead?.Invoke();
        }

        OnHealthChanged?.Invoke(currentHp, stats.MaxHp);
    }

    public void ResetHpToMax()
    {
        if (Stats != null)
        {
            currentHp = Stats.MaxHp;
            OnHealthChanged?.Invoke(currentHp, stats.MaxHp);
        }
        else
            currentHp = Mathf.Max(1f, currentHp);
    }
}
