using System;
using System.Collections.Generic;
using UnityEngine;
using static Define;

// ������ �߿��� Ȱ��ȭ ���� ����� Manager�� �ڵ尡 ����
[DisallowMultipleComponent]
public class EchoRecorder : MonoBehaviour
{
    public float sampleDeltaTime = 0.05f;

    IAnimationController anim;
    EchoTape tape;
    float totalTime, sampleTime;

    Rigidbody2D rb;
    HealthController hc;

    bool lastMove;
    float lastHp;
    const float MOVE_EPS = 0.05f;   // ���� ����
    const float HP_EPS = 0.0001f;

    void Awake()
    {
        anim = GetComponent<IAnimationController>();
        rb = GetComponent<Rigidbody2D>();
        hc = GetComponent<HealthController>();
    }

    public void BeginRecord()
    {
        totalTime = 0f; sampleTime = 0f;
        tape = new EchoTape();
        lastMove = false;

        if (hc != null) 
            lastHp = hc.CurrentHp;

        // ������Ʈ Ȱ��ȭ���� fixedUpdate �ǽ�
        enabled = true;
    }

    public EchoTape EndRecord(bool wasClear)
    {
        enabled = false;
        if (tape != null)
        {
            tape.length = totalTime;
            tape.wasClear = wasClear;

            // ��� ���� �ִϸ��̼� Ŭ���� ȣ�� ������ �������� ���
            if (!wasClear)
            {
                float tt = Mathf.Max(0f, totalTime - 0.01f);
                tape.animParams.Add(new EchoTape.AnimParamEvt { t = tt, type = "bool", name = "isDeath", value = 1 });
                tape.animParams.Add(new EchoTape.AnimParamEvt { t = tt, type = "trig", name = "4_Death", value = 0 });
            }

            // ���� ���� ���
            TrySnapshotEquipment(tape);
            TrySnapshotVisuals(tape);
        }
        return tape;
    }

    void FixedUpdate()
    {
        if (tape == null) // Begin���� �ʾҰų� End�Ǿ��� �� ����
            return;

        totalTime += Time.fixedDeltaTime;
        sampleTime += Time.fixedDeltaTime;

        // �̵� ������ ���� Ȯ��
        bool moving = false;
#if UNITY_6000_0_OR_NEWER
        // RB�κ��� �ӵ��� �о �̵� ���� �Ǵ�
        // magnitude :  ���� ũ��(���� ���)
        // sqrMagnitudE : ���� ũ�� ���� (���� ����)
        if (rb != null)
            moving = rb.linearVelocity.sqrMagnitude > (MOVE_EPS * MOVE_EPS);
#else
        if (rb != null)
            moving = rb.velocity.sqrMagnitude > (MOVE_EPS * MOVE_EPS);
#endif
        if (sampleTime >= sampleDeltaTime)
        {
            sampleTime = 0f;

            // ������ �ű� ����
            var f = new EchoTape.Frame
            {
                t = totalTime,
                pos = transform.position,
                faceRight = transform.localScale.x >= 0f,
                clip = anim?.GetCurClipname()
            };
            tape.frames.Add(f);

            // �̵� ����? �ٷ� Move �̺�Ʈ
            if (moving != lastMove)
            {
                tape.animParams.Add(new EchoTape.AnimParamEvt
                {
                    t = totalTime,
                    type = "bool",
                    name = "1_Move",
                    value = moving ? 1 : 0
                });
                lastMove = moving;
            }

            // �ǰ�? 3_Damaged Ʈ����
            if (hc != null)
            {
                float cur = hc.CurrentHp;
                if (cur < lastHp - HP_EPS)
                {
                    tape.animParams.Add(new EchoTape.AnimParamEvt
                    {
                        t = totalTime,
                        type = "trig",
                        name = "3_Damaged",
                        value = 0
                    });
                }
                lastHp = cur;
            }
        }
    }

    // ���� �̺�Ʈ ���
    public void MarkActionBegin(string id, float factor = 1f)
    {
        tape?.events.Add(new EchoTape.ActionEvt { t = totalTime, kind = "AtkBegin", id = id, value = factor });
        tape?.animParams.Add(new EchoTape.AnimParamEvt { t = totalTime, type = "trig", name = "2_Attack", value = 0 });
    }

    public void MarkActionEnd(string id)
        => tape?.events.Add(new EchoTape.ActionEvt { t = totalTime, kind = "AtkEnd", id = id, value = 0f });

    // ������ ��� ���
    public void MarkItemUsed(string itemId)
    {
        if (!string.IsNullOrEmpty(itemId))
            tape?.usedItemIds.Add(itemId);
    }

    //������ ���� ���� ���
    private void TrySnapshotEquipment(EchoTape dest)
    {
        var eq = GetComponentInChildren<EquipmentManager>(true);
        if (eq == null) return;

        foreach (EquipmentSlot slot in (EquipmentSlot[])Enum.GetValues(typeof(EquipmentSlot)))
        {
            var item = eq.GetEquipped(slot);
            if (item != null)
            {
                dest.equipped.Add(new EchoTape.EquipEntry
                {
                    slot = slot.ToString(),
                    itemId = item.name
                });
            }
        }
    }

    // Player������Ʈ ������ ��� SpriterRenderer�� ���Ͽ� ����.
    private void TrySnapshotVisuals(EchoTape dest)
    {
        var unitRoot = this.transform;
        var root = unitRoot.Find("Root");
        if (root == null)
        {
            return;
        }

        var srs = root.GetComponentsInChildren<SpriteRenderer>(true);
        foreach (var sr in srs)
        {
            var relPath = GetRelativePath(sr.transform, root);
            if (string.IsNullOrEmpty(relPath)) continue;

            var vp = new EchoTape.VisualPart
            {
                path = relPath,
                sprite = sr.sprite ? sr.sprite.name : string.Empty,
                localPosOffset = Vector2.zero,
                localScaleMul = new Vector2(1f, 1f),
                sortingOffset = 0,
                enabled = sr.enabled,
                changeMaskInteraction = true,
                maskInteraction = (int)sr.maskInteraction
            };

            var mask = sr.GetComponent<SpriteMask>();
            vp.enablePartSpriteMask = (mask ? mask.enabled : false);

            dest.visualParts.Add(vp);
        }
    }

    private static string GetRelativePath(Transform t, Transform root)
    {
        if (t == null || root == null) return null;
        List<string> seg = new List<string>();
        var cur = t;
        while (cur != null && cur != root)
        {
            seg.Add(cur.name);
            cur = cur.parent;
        }
        if (cur != root) return null;
        seg.Reverse();
        return string.Join("/", seg);
    }
}
