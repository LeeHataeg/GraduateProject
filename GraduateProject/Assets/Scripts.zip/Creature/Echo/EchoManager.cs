using System.Collections.Generic;
using UnityEngine;

public class EchoManager : MonoBehaviour
{
    #region ����
    public static EchoManager I { get; private set; }

    [Header("Ghost")]
    public EchoPlayback ghostPrefab;
    [Tooltip("������ �͡濬�� ������, �ֽš����� ������")]
    public float[] alphaByAge = { 0.20f, 0.28f, 0.36f, 0.45f, 0.60f };

    EchoRecorder recorder;
    PlayerController player;

    #endregion

    public void BeginBossBattle(PlayerController playerController)
    {
        player = playerController;

        // ���� Ŭ���� ���� ����
        var stash = EchoPersistence.LoadStash();
        foreach (var id in stash) EchoInventoryBridge.TryGiveItemToPlayer(player, id);

        // ��� ��� ���
        var tapes = EchoPersistence.LoadTapes();
        int n = tapes.Count;
        for (int i = 0; i < n; i++)
        {
            var tape = tapes[i];
            var spawnPos = (tape.frames.Count > 0) ? (Vector3)tape.frames[0].pos : player.transform.position;

            var ghost = Instantiate(ghostPrefab, spawnPos, Quaternion.identity);
            ghost.Load(tape);
            ghost.AttachVisualFrom(player);

            int idx = Mathf.Clamp(alphaByAge.Length - (n - i), 0, alphaByAge.Length - 1);
            ghost.SetAlpha(alphaByAge[idx]);
        }

        // ��� ����
        recorder = player.GetComponent<EchoRecorder>();
        if (!recorder) recorder = player.gameObject.AddComponent<EchoRecorder>();
        recorder.BeginRecord();
    }

    public void EndBossBattle(bool playerDied)
    {
        var tape = recorder?.EndRecord(!playerDied);

        if (playerDied)
        {
            if (tape != null) EchoPersistence.PushDeathTapeFIFO(tape);
        }
        else
        {
            // Ŭ���� ���� ����
            EchoPersistence.HarvestItemsFromAllTapes_ThenClear();
        }

        // Ŭ���� ���� ����
        EchoPersistence.SaveStash(new List<string>());
    }

    void Awake()
    {
        if (I != null) { Destroy(gameObject); return; }
        I = this; DontDestroyOnLoad(gameObject);
    }

}
