using TMPro;
using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class InventoryUI : MonoBehaviour
{
    [Header("Popup & Slot Prefab")]
    public RectTransform popupPanel;
    public Image popupIcon;
    public TextMeshProUGUI popupName;
    public TextMeshProUGUI popupDesc;

    [Header("Slot")]
    public Transform slotContainer;     // Grid/VerticalLayout ��
    public GameObject slotPrefab;       // �ݵ�� InventorySlotUI ���Ե� ������

    private InventorySystem inventory;

    void Awake()
    {
        // ���� Ȯ���� ���� �κ��� ���� �õ� �� ������ ������ �˻�
        inventory = GameManager.Instance?.UIManager?.InventorySys
                    ?? Object.FindFirstObjectByType<InventorySystem>(FindObjectsInactive.Include);

        if (inventory != null) inventory.OnInventoryChanged += RefreshUI;
        else Debug.LogWarning("[InventoryUI] InventorySystem�� ���� �� ã��. ���� SetInventory���� ���� ����.", this);

        if (popupPanel) popupPanel.gameObject.SetActive(false);
    }

    void Start()
    {
        RefreshUI(); // ù ǥ��
    }

    void OnDestroy()
    {
        if (inventory != null) inventory.OnInventoryChanged -= RefreshUI;
    }

    public InventorySystem GetInventoryUnsafe() => inventory; // ������ ������ �� �ֵ��� ����

    private void EnsureSlots()
    {
        if (slotContainer == null || slotPrefab == null || inventory == null) return;

        int need = inventory.capacity;
        int have = slotContainer.childCount;

        for (int i = have; i < need; i++)
        {
            var go = Instantiate(slotPrefab, slotContainer);
            go.name = $"Slot_{i:00}";

            // �� ���⼭ ���� inventory�� ���Կ� ����
            var ui = go.GetComponent<InventorySlotUI>();
            if (ui != null) ui.Bind(this, inventory);

            var img = go.GetComponent<Image>();
            if (img == null) img = go.AddComponent<Image>();
            img.raycastTarget = true;
            if (img.sprite == null) img.color = new Color(1, 1, 1, 0.001f);
        }
    }

    public void RefreshUI()
    {
        if (slotContainer == null) { Debug.LogWarning("[InventoryUI] slotContainer ���Ҵ�", this); return; }
        if (inventory == null) return;

        EnsureSlots();

        var slotUIs = slotContainer.GetComponentsInChildren<InventorySlotUI>(includeInactive: true);
        int uiCount = slotUIs.Length;
        int dataCount = inventory.slots.Count;

        for (int i = 0; i < uiCount; i++)
        {
            // �� Ȥ�ö� �������� �ٲ� �κ� ������ ����
            if (slotUIs[i] != null) slotUIs[i].Bind(this, inventory);

            if (i < dataCount) slotUIs[i].SetData(inventory.slots[i], i);
            else slotUIs[i].SetEmpty();
        }
    }
    // Tooltip
    public void ShowPopup(InventorySlot slot, Vector2 screenPos)
    {
        if (slot.item == null || popupPanel == null) return;
        popupIcon.sprite = slot.item.icon;
        popupName.text = slot.item.itemName;
        popupDesc.text = slot.item.description;
        popupPanel.gameObject.SetActive(true);
        popupPanel.position = screenPos + new Vector2(popupPanel.rect.width * 0.5f, -popupPanel.rect.height * 0.5f);
    }

    public void SetInventory(InventorySystem sys)
    {
        if (inventory != null) inventory.OnInventoryChanged -= RefreshUI;
        inventory = sys;
        if (inventory != null) inventory.OnInventoryChanged += RefreshUI;
        RefreshUI();
    }

    public void HidePopup()
    {
        if (popupPanel) popupPanel.gameObject.SetActive(false);
    }
}
