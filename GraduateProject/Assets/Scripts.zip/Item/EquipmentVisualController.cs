using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using static Define;

[RequireComponent(typeof(EquipmentManager))]
[DisallowMultipleComponent]
public class EquipmentVisualController : MonoBehaviour
{
    // �⺻ �������� (0,0,1) ���� �������� �� ���� ����� 0�� �Ǵ� ���� �����ϱ� ���� ����
    private static Vector3 BaseScale(Vector3 s)
    {
        float bx = Mathf.Approximately(s.x, 0f) ? 1f : s.x;
        float by = Mathf.Approximately(s.y, 0f) ? 1f : s.y;
        float bz = Mathf.Approximately(s.z, 0f) ? 1f : s.z;
        return new Vector3(bx, by, bz);
    }

    [Serializable]
    public class PartBinding
    {
        public Define.BodyPart part;
        public SpriteRenderer renderer;       // �ʼ�
        public SpriteMask optionalMask;       // ����(���� ��)

        // �⺻ ���� ���
        [HideInInspector] public Sprite defaultSprite;
        [HideInInspector] public Vector3 defaultLocalPos;
        [HideInInspector] public Vector3 defaultLocalScale;
        [HideInInspector] public int defaultSortingOrder;
        [HideInInspector] public bool defaultEnabled;
        [HideInInspector] public SpriteMaskInteraction defaultMaskInteraction;
        [HideInInspector] public bool defaultMaskEnabled;
    }

    [Serializable]
    public class SlotDefaultTargets
    {
        public EquipmentSlot slot;
        public Define.BodyPart[] defaultParts;  // visuals ���� �� icon�� �ȱ� Ÿ�ٵ�
    }

    [Header("��ü ��Ʈ ���ε�")]
    public PartBinding[] parts;

    [Header("���Ժ� �⺻ ������ �ȱ� ���")]
    public SlotDefaultTargets[] slotDefaults =
    {
        new SlotDefaultTargets{ slot=EquipmentSlot.Head,  defaultParts=new[]{ Define.BodyPart.Hat } },
        new SlotDefaultTargets{ slot=EquipmentSlot.Chest, defaultParts=new[]{ Define.BodyPart.Chest } },
        new SlotDefaultTargets{ slot=EquipmentSlot.Legs,  defaultParts=new[]{ Define.BodyPart.LegL, Define.BodyPart.LegR } },
        new SlotDefaultTargets{ slot=EquipmentSlot.Weapon,defaultParts=new[]{ Define.BodyPart.WeaponR } },
        // �ʿ信 �°� �߰�/����
    };

    private EquipmentManager eq;

    // ���Ժ��� ��� ������ ������ ��Ʈ ��� ����(������)
    private readonly Dictionary<EquipmentSlot, List<Define.BodyPart>> modifiedBySlot = new();

    // ���� ��ȸ�� ���� ��
    private Dictionary<Define.BodyPart, PartBinding> map;
    private Dictionary<EquipmentSlot, Define.BodyPart[]> defaultMap;

    void Awake()
    {
        eq = GetComponent<EquipmentManager>() ?? FindFirstObjectByType<EquipmentManager>();
        eq.OnEquippedChanged -= OnEquippedChanged;
        eq.OnEquippedChanged += OnEquippedChanged;

        map = parts.Where(p => p != null && p.renderer != null)
                   .ToDictionary(p => p.part, p => p);

        defaultMap = slotDefaults.ToDictionary(d => d.slot, d => d.defaultParts ?? Array.Empty<Define.BodyPart>());

        // �⺻�� ��� (���� �״�� ���: ���� �� �� ���·� ����)
        foreach (var b in map.Values)
        {
            b.defaultSprite = b.renderer.sprite;
            b.defaultLocalPos = b.renderer.transform.localPosition;
            b.defaultLocalScale = b.renderer.transform.localScale;
            b.defaultSortingOrder = b.renderer.sortingOrder;
            b.defaultEnabled = b.renderer.enabled;
            b.defaultMaskInteraction = b.renderer.maskInteraction;
            b.defaultMaskEnabled = b.optionalMask ? b.optionalMask.enabled : false;
        }
    }

    void OnDestroy()
    {
        if (eq) eq.OnEquippedChanged -= OnEquippedChanged;
    }

    void OnEquippedChanged(EquipmentSlot slot, EquipmentItemData item)
    {
        RestoreSlot(slot);
        ApplySlot(slot, item);
    }

    private void RestoreSlot(EquipmentSlot slot)
    {
        if (!modifiedBySlot.TryGetValue(slot, out var list) || list == null) return;

        foreach (var part in list)
        {
            if (!map.TryGetValue(part, out var b) || b.renderer == null) continue;

            // �⺻���� ����
            b.renderer.sprite = b.defaultSprite;
            b.renderer.transform.localPosition = b.defaultLocalPos;
            b.renderer.transform.localScale = b.defaultLocalScale;
            b.renderer.sortingOrder = b.defaultSortingOrder;
            b.renderer.enabled = b.defaultEnabled;
            b.renderer.maskInteraction = b.defaultMaskInteraction;

            if (b.optionalMask) b.optionalMask.enabled = b.defaultMaskEnabled;
        }

        list.Clear();
    }

    private void ApplySlot(EquipmentSlot slot, EquipmentItemData item)
    {
        if (!modifiedBySlot.ContainsKey(slot))
            modifiedBySlot[slot] = new List<Define.BodyPart>();
        var modified = modifiedBySlot[slot];

        if (item == null) return;

        // �� 1) Chest ���� �ɼ��� ������ �켱 ����
        if (slot == EquipmentSlot.Chest && item.armor != null && item.armor.enable)
        {
            ApplyChestArmor(item, modified);
            return;
        }

        // 2) �Ϲ� VisualOverride�� ������ �װ� ���
        if (item.visuals != null && item.visuals.Count > 0)
        {
            foreach (var v in item.visuals)
                ApplyVisualOverride(v, item.icon, modified);
            return;
        }

        // 3) ����: slotDefaults�� ���ǵ� ��Ʈ�鿡 icon�� �ȱ�
        if (item.icon != null && defaultMap.TryGetValue(slot, out var targets))
        {
            foreach (var part in targets)
                ApplySpriteToPart(part, item.icon, Vector2.zero, Vector2.one, 0, track: true, modified);
        }
    }

    // --- Chest ���� ���� ---
    private void ApplyChestArmor(EquipmentItemData item, List<Define.BodyPart> modified)
    {
        // Chest
        Sprite chestSprite = item.armor.chestSprite ? item.armor.chestSprite : item.icon;
        if (chestSprite) // ��������Ʈ�� �����鸸 ����
        {
            ApplySpriteToPart(Define.BodyPart.Chest, chestSprite,
                item.armor.chestOffset, item.armor.chestScale, item.armor.chestSortingOffset,
                track: true, modified);
        }

        // Shoulder L
        if (item.armor.shoulderLeftSprite)
        {
            ApplySpriteToPart(Define.BodyPart.ShoulderL, item.armor.shoulderLeftSprite,
                item.armor.shoulderLOffset, item.armor.shoulderLScale, item.armor.shoulderLSortingOffset,
                track: true, modified);
        }

        // Shoulder R
        if (item.armor.shoulderRightSprite)
        {
            ApplySpriteToPart(Define.BodyPart.ShoulderR, item.armor.shoulderRightSprite,
                item.armor.shoulderROffset, item.armor.shoulderRScale, item.armor.shoulderRSortingOffset,
                track: true, modified);
        }
        else if (item.armor.mirrorRightFromLeft && item.armor.shoulderLeftSprite)
        {
            // �������� ���� �̷������� ��ü (scale.x ��ȣ ����)
            var mirroredScale = new Vector2(-item.armor.shoulderLScale.x, item.armor.shoulderLScale.y);
            ApplySpriteToPart(Define.BodyPart.ShoulderR, item.armor.shoulderLeftSprite,
                item.armor.shoulderROffset, mirroredScale, item.armor.shoulderRSortingOffset,
                track: true, modified);
        }
    }

    // --- ���� �������̵� ���� ---
    private void ApplyVisualOverride(VisualOverride v, Sprite iconFallback, List<Define.BodyPart> modified)
    {
        if (!map.TryGetValue(v.part, out var b) || b.renderer == null)
        {
            Debug.LogWarning($"[EVC] Missing PartBinding or SpriteRenderer for {v.part} on {name}");
            return;
        }

        // ��������Ʈ ����
        Sprite use = v.sprite;
        if (!use && v.useIconIfEmpty) use = iconFallback;

        if (v.hideRenderer)
        {
            b.renderer.enabled = false;
        }
        else
        {
            b.renderer.enabled = true;
            if (use) b.renderer.sprite = use;
        }

        // ��ġ/������/����
        b.renderer.transform.localPosition = b.defaultLocalPos + (Vector3)v.offset;
        {
            var baseScale = BaseScale(b.defaultLocalScale);
            float sx = Mathf.Approximately(v.scale.x, 0f) ? 1f : v.scale.x;
            float sy = Mathf.Approximately(v.scale.y, 0f) ? 1f : v.scale.y;
            b.renderer.transform.localScale = new Vector3(baseScale.x * sx, baseScale.y * sy, baseScale.z);
        }
        b.renderer.sortingOrder = b.defaultSortingOrder + v.sortingOrderOffset;

        if (v.changeMaskInteraction)
            b.renderer.maskInteraction = v.maskInteraction;
        if (b.optionalMask)
            b.optionalMask.enabled = v.enablePartSpriteMask;

        if (!modified.Contains(v.part)) modified.Add(v.part);
    }

    // --- ����: Ư�� ��Ʈ�� ��������Ʈ �ȱ� ---
    private void ApplySpriteToPart(Define.BodyPart part, Sprite sprite,
        Vector2 offset, Vector2 scale, int sortingOffset,
        bool track, List<Define.BodyPart> modified)
    {
        if (!map.TryGetValue(part, out var b) || b.renderer == null)
        {
            Debug.LogWarning($"[EVC] Missing PartBinding or SpriteRenderer for {part} on {name}");
            return;
        }
        b.renderer.enabled = true;
        b.renderer.sprite = sprite;

        // ��ġ/������/����
        b.renderer.transform.localPosition = b.defaultLocalPos + (Vector3)offset;
        {
            var baseScale = BaseScale(b.defaultLocalScale);
            float sx = Mathf.Approximately(scale.x, 0f) ? 1f : scale.x;
            float sy = Mathf.Approximately(scale.y, 0f) ? 1f : scale.y;
            b.renderer.transform.localScale = new Vector3(baseScale.x * sx, baseScale.y * sy, baseScale.z);
        }
        b.renderer.sortingOrder = b.defaultSortingOrder + sortingOffset;

        if (track && !modified.Contains(part)) modified.Add(part);
    }
}
