using UnityEngine;
using static Define;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class EquipmentSlotUI : MonoBehaviour, IPointerClickHandler
{
    public EquipmentSlot slot;
    public Image icon;

    private EquipmentUI owner;

    // �� �θ𿡼� �ڵ� ���ε� (�Ǽ��� Bind �� �ҷ��� ����)
    private void Awake()
    {
        if (owner == null)
            owner = GetComponentInParent<EquipmentUI>();
    }

    public void Bind(EquipmentUI owner) => this.owner = owner;

    public void Refresh(EquipmentItemData item)
    {
        if (icon == null) return; // ���� ����

        if (item)
        {
            icon.enabled = true;
            icon.sprite = item.icon;
        }
        else
        {
            icon.enabled = false;
            icon.sprite = null;
        }
    }

    // ��Ŭ���ϸ� ��� ����
    public void OnPointerClick(PointerEventData e)
    {
        if (e.button != PointerEventData.InputButton.Right) return;

        if (owner != null)
        {
            owner.RequestUnequip(slot);
        }
        else
        {
            // ������ ��: �� �ڸ����� �θ� Ž�� �� ��õ�
            Debug.LogWarning($"[EquipmentSlotUI] owner is null on {name}. Auto-binding now.");
            owner = GetComponentInParent<EquipmentUI>();
            if (owner != null) owner.RequestUnequip(slot);
        }
    }
}
