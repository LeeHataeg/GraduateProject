using System.Collections.Generic;
using UnityEngine;
using static Define;

public class EquipmentUI : MonoBehaviour
{
    public EquipmentManager eq;
    public List<EquipmentSlotUI> slots = new();

    private void Awake()
    {
        BindSlots();          // �� ���Ե鿡 this ���ε�
    }

    private void OnEnable()
    {
        // (������Ʈ�� ���� ���� ����/���� ���� �ִ� �̺�Ʈ�� �״�� �ΰ�, ������ �ּ� ó���ϼ���)
        var pm = GameManager.Instance?.PlayerManager;
        if (pm != null) pm.OnEquipmentReady += HandleEqReady;

        TryAttachExisting();
        RefreshAll();
    }

    private void OnDisable()
    {
        var pm = GameManager.Instance?.PlayerManager;
        if (pm != null) pm.OnEquipmentReady -= HandleEqReady;
        if (eq != null) eq.OnEquippedChanged -= OnEquippedChanged;
    }

    private void BindSlots()
    {
        if (slots == null || slots.Count == 0)
            slots = new List<EquipmentSlotUI>(GetComponentsInChildren<EquipmentSlotUI>(true));

        foreach (var s in slots)
            if (s != null) s.Bind(this);   // �� Ȯ���� ������
    }

    private void HandleEqReady(EquipmentManager mgr) => AttachEq(mgr);

    private void TryAttachExisting()
    {
        var p = GameManager.Instance?.PlayerManager?.Player;
        if (!p) return;

        var mgr = p.GetComponentInChildren<EquipmentManager>(true);
        if (mgr) AttachEq(mgr);
    }

    private void AttachEq(EquipmentManager mgr)
    {
        if (eq != null) eq.OnEquippedChanged -= OnEquippedChanged;
        eq = mgr;
        if (eq != null) eq.OnEquippedChanged += OnEquippedChanged;
        RefreshAll();
    }

    public void RefreshAll()
    {
        if (!eq) return;
        foreach (var s in slots)
            if (s != null) s.Refresh(eq.GetEquipped(s.slot));
    }

    private void OnEquippedChanged(EquipmentSlot slot, EquipmentItemData item)
    {
        RefreshAll();
    }

    // EquipmentUI.cs
    public void RequestUnequip(EquipmentSlot slot)
    {
        if (eq != null && eq.TryUnequip(slot, out var removed) && removed != null)
        {
            // �κ��� �ֱ� (����ĭ�� ���� �� �ִٸ� ���� üũ ������ �߰��ص� ��)
            GameManager.Instance?.UIManager?.InventorySys?.AddItem(removed, 1);
            RefreshAll();
        }
    }

}
