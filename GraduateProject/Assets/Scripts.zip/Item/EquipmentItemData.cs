using System.Collections.Generic;
using UnityEngine;
using static Define;

[CreateAssetMenu(menuName = "Inventory/Equipment Item")]
public class EquipmentItemData : ItemData
{
    [Header("Equipment Info")]
    public EquipmentSlot slot;
    public List<StatModifier> modifiers = new List<StatModifier>();

    [Header("Visual Overrides (optional)")]
    public List<VisualOverride> visuals = new();  // Hat/Hair/���� ���� ���� ��� ����

    [Header("Armor (Chest) Options")]
    public ArmorVisualOptions armor;              // �� Chest ���� �ɼ�
}
