using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class StageButtonUI : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI label;
    [SerializeField] private Button button;
    [SerializeField] private GameObject lockIcon;  // ��� ǥ�ÿ� (���û���)

    public int StageIndex { get; private set; }

    public void Init(int stageIndex, System.Action<int> onClick)
    {
        StageIndex = stageIndex;

        if (label != null)
            label.text = $"Stage {stageIndex}";

        if (button != null)
        {
            button.onClick.RemoveAllListeners();
            button.onClick.AddListener(() => onClick?.Invoke(stageIndex));
        }
    }

    public void SetUnlocked(bool unlocked)
    {
        if (button != null)
            button.interactable = unlocked;

        if (lockIcon != null)
            lockIcon.SetActive(!unlocked);
    }

    public void SetSelected(bool selected)
    {
        // ���� ȿ�� (�� �ٲٱ� ��) �ְ� ������ ���⼭ ó��
        // ��: ��ư ��� ��, outline ��
    }
}
