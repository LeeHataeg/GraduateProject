using UnityEngine;

public class PlayerPositionController : MonoBehaviour
{
    private Transform _target;

    public void SetTarget(Transform t) => _target = t;

    public void SetPosition(Vector2 worldPos)
    {
        if (_target != null)
            _target.position = worldPos;
        else
            Debug.LogWarning("[PlayerPositionController] Target ������. SetTarget ���� ȣ���ϼ���.");
    }
}
